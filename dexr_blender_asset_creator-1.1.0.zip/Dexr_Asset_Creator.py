bl_info = {
    "name": "Dexr Asset Creator",
    "author": "Dexr",
    "version": (1, 1,2),
    "blender": (3, 60, 0),
    "location": "View3D > Toolbar > DEXR Asset Creator",
    "description": "Create & Manage your Dexr Assets",
    "warning": "",
    "doc_url": "",
    "category": "Import-Export",
}

import bpy
import pathlib
from pathlib import Path
import pprint
import json
import os
import uuid
import webbrowser
import mathutils
import math
import requests
from requests.auth import HTTPDigestAuth
import time
from bl_ui.generic_ui_list import draw_ui_list
from mathutils import Euler
import math
import functools
import base64
import time
import datetime
# import jwt
# from auth0.authentication import GetToken


from bpy.props import StringProperty, CollectionProperty,PointerProperty,BoolProperty,EnumProperty, IntProperty,FloatVectorProperty,IntVectorProperty
from bpy.types import Operator, Panel
from bpy.app.handlers import persistent
import gpu

# Your images
image_files = ['//dexr_logo_white_smaller.png']
# GPU textures
textures = []

objectPositions = {}
global PipelineCollection
DuplicatedObjects = []
IsAuthenticated = False
NeedsAuthRefresh = False
AUTH0_PollCounter = 0
AUTH0_PollCountMax = 10
Batch_current_index = 0
collections_to_process = []
IsInitializing = False

APIURL_localhost = "http://localhost:3000/v1/"
APIURL_Development = "https://dev-api.dexr.eu/v1/"
APIURL_Production = "https://api.dexr.eu/v1/"
APIURL_baseUrl = APIURL_Production
APIURL_UploadAssetThumbnailUrl = "resources/thumbnails/assets/"
APIURL_UploadTexturesUrl = "resources/dexr/textures/"
APIURL_UploadModelsUrl = "resources/dexr/"
APIURL_UpdateAsset = "assets/"
APIURL_MoveAsset = "assets/moveToAssetCollection"
authToken = ''
authHeader = ""
productHeader = {'product': 'BlenderAddon' }
AUTH0_CLIENT_ID_DEV = "dDFiVVNPcFI3RGhBT2lDNDJJMWt0SlplZjIwVXNhdFc="
AUTH0_CLIENT_ID_PROD = "QmlwbDVQU1lNZ3R3ekNaQ0JvOXZsQ2g0enhlb3J2OVE="
AUTH0_DOMAIN_DEV = "dev-dexr.eu.auth0.com"
AUTH0_DOMAIN_PROD = "dexr.eu.auth0.com"
AUTH0_AUDIENCE_DEV = "https://dev-api.dexr.eu/"
AUTH0_AUDIENCE_PROD = "https://api.dexr.eu/"

# =====================================================
#                       Properties
# =====================================================

class DexrEnvironment(bpy.types.PropertyGroup):
    name: StringProperty()
    id: StringProperty()
class AssetDefinition(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name="name",
        description=":",
        default="category_type_name_size",
        maxlen=1024,
        )
    id: bpy.props.StringProperty(
        name="id",
        description="",
        default="ids should be generated",
        maxlen=1024,
        )
class DexrAssetGroup(bpy.types.PropertyGroup):
    id: StringProperty()
    name: StringProperty()
    ownerId: StringProperty()
class DexrSpace(bpy.types.PropertyGroup):
    name: StringProperty()
    id: StringProperty()
    ownerId: StringProperty()
    assetCollections: bpy.props.CollectionProperty(type=DexrAssetGroup)
class UserSettings(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name="name",
        description=":",
        default="",
        maxlen=1024,
        )
    email: bpy.props.StringProperty(
        name="email",
        description="",
        default="",
        maxlen=1024,
        )
    isAdmin: bpy.props.BoolProperty(default=False)
    spaces: bpy.props.CollectionProperty(type=DexrSpace)
    # roles: bpy.props.CollectionProperty(type=UserRole)

class AdminSettings(bpy.types.PropertyGroup):
    production : bpy.props.BoolProperty(default=True)
    publicOrPrivate: bpy.props.BoolProperty(default=False)

class AddonSettings(bpy.types.PropertyGroup):
    useSelected: bpy.props.BoolProperty(
        name="Export Selected only (N/I)",
        description=":",
        default=False
        )
    UseCurrentCollection: bpy.props.BoolProperty(
        name="Use Active collection",
        description="Only use the items in the active collection instead of the whole scene file. TODO: export whole scene.",
        default=True
        )
    resetPivot: bpy.props.BoolProperty(
        name="Set Pivot to [0,0,0]",
        description="Sometimes you want to organize your file in many collections. To keep a nice overview you spread the items out visually. For exporting purposes though the objects need to be on the world zero [0,0,0]. This option will put your object there and then back",
        default=False
        )
    CompressToJPEG: bpy.props.BoolProperty(
        name="Use JPEG instead of PNG",
        description="JPG is a lot more compressed, but can cause artefacts. PNG is lossess, but has bigger filesize",
        default=True
        )
    AutomaticMode: bpy.props.BoolProperty(
        name="Auto Export Mode",
        description="With the automatic mode, we will process your asset with default setting but the process is much simplified. With manual mode you have more finegrained control, but there are a few more steps to go through.",
        default=True
        )


class DexrTransform(bpy.types.PropertyGroup):
    position: FloatVectorProperty(subtype="XYZ",default=mathutils.Vector((0,0,0)))
    eulerRotation:FloatVectorProperty(subtype="XYZ",default=mathutils.Vector((0,0,0)))
    scale:FloatVectorProperty(subtype="XYZ",default=mathutils.Vector((0,0,0)))
class Interactable(bpy.types.PropertyGroup):
    title: bpy.props.StringProperty(
        name="title",
        description=":",
        default="title",
        maxlen=1024,
        )
    id: bpy.props.StringProperty(
        name="id",
        description="",
        default="id",
        maxlen=1024,
        )
    targetName: bpy.props.StringProperty(
        name="targetName",
        description="",
        default="subobject",
        maxlen=1024,
        )
    initialState: bpy.props.StringProperty(
        name="initialState",
        description="",
        default="default",
        maxlen=1024,
        )
MeshChangeTypeEnumValues= [('0',"changeTransform",""),('1',"changeObjectVisibility",""),('2',"changeMaterialProperty",""),('3',"playAnimation","")]
class MeshChange(bpy.types.PropertyGroup):
    type: bpy.props.EnumProperty(
        name="type",
        description="",
        items=MeshChangeTypeEnumValues
        )
    durationInMilliseconds: bpy.props.IntProperty(
        name="durationInMilliseconds",
        description="",
        default=330,
    )
    targetName: bpy.props.StringProperty(
        name="targetName",
        description="",
        default="nothing selected",
        maxlen=1024,
        )
    isVisible: bpy.props.BoolProperty()
    animationName: bpy.props.StringProperty()
    materialSlot: bpy.props.IntProperty(default=0)
    propertyName: bpy.props.StringProperty()
    transform: PointerProperty(type=DexrTransform )
    isApplied: BoolProperty(default=False)
AssetTypeEnumValues=[('0',"mesh","not grabbable"),('1',"item","grabbable")]
class AssetClass(bpy.types.PropertyGroup):
     type: bpy.props.EnumProperty(
        name="type",
        description="",
        items=AssetTypeEnumValues
        )
     title: bpy.props.StringProperty(
        name="title",
        description="",
        default="title",
        maxlen=1024,
        )
     id: bpy.props.StringProperty(
        name="id",
        description="",
        default="",
        maxlen=1024,
        )
     isVisibleInCatalog: bpy.props.BoolProperty(
        name="isVisibleInCatalog",
        description="assets that should be hidden in catalog are the ones from environments",
        default=True,
        )
class MeshState(bpy.types.PropertyGroup):
    title: bpy.props.StringProperty(
        name="title",
        description="",
        default="title",
        maxlen=1024,
        )
    id: bpy.props.StringProperty(
        name="id",
        description="",
        default="",
        maxlen=1024,
        )
    changes: bpy.props.CollectionProperty(type=MeshChange)#(name="changes")

    def update_func(self, context):
        print("my test function", self)


# =====================================================
#                       UI
# =====================================================

class Login_Panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "| Step 1 |--> Authenticate with a Dexr User"
    bl_idname = "SCENE_PT_layout_DexrAuthPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DEXR'

    # def __init__(self):
    #     #preload use images
    #     for img_file in image_files:
    #         # Load image
    #         imgName= img_file.replace('/','')
    #         if not (imgName in bpy.data.images):
    #             print("loading logo")
    #             img = bpy.data.images.load(img_file)
    #         else:
    #             img = bpy.data.images[imgName]
    #         if(img is not None) :
    #             if not imgName in bpy.data.textures:
    #                 print("loading logo texture")
    #                 tex = bpy.data.textures.new(name=imgName, type="IMAGE")
    #                 tex.image = img
    #                 tex.extension = 'CLIP'
    #                 tex.alpha = False

            # Create GPU texture
            # (see https://docs.blender.org/api/current/gpu.html#d-image)
            # textures.append(gpu.texture.from_image(img))

            # Remove image, so it won't show in the Image list in the UI
            # bpy.data.images.remove(img)

        # bpy.types.Panel.__init__(self)

    def draw(self, context):
        layout = self.layout
        Init()
        scene = context.scene
        settings = scene.UserSettings

        #Trying to display a logo
        #---------------------------
        # if "dexr_logo_white_smaller.png" in bpy.data.textures:
        #         tex = bpy.data.textures['dexr_logo_white_smaller.png']
        #         # col = layout.split(factor=0.5)
        #         col = layout.row()
        #         col.template_preview(tex)

        if(Authenticated()):

            spaces = bpy.context.scene.UserSettings.spaces
            scene = bpy.context.scene
            row = layout.row()
            layout.label(text="Currently logged in with")
            row = layout.row()
            row.enabled = False
            row.prop(settings, "name")
            row = layout.row()
            row.enabled = False
            row.prop(settings, "email")

            global NeedsAuthRefresh
            if not NeedsAuthRefresh:
                row = layout.row()
                row.enabled = True
                layout.label(text="Spaces")
                draw_ui_list(
                    layout,
                    context,
                    list_path="scene.UserSettings.spaces",
                    active_index_path="scene.SelectedSpace",
                    unique_id="Spaces_id"
                )

                # row = layout.row()
                # row.enabled = False
                # row.prop(settings, "roles")
                # row = layout.row()
                # row.enabled = False
                # row.prop(context.scene,"AuthenticationToken",text="token")
                row = layout.row()
                layout.label(text=f"valid until {GetTokenExpiryDateStamp()}")
                row = layout.row()
                row.operator("api.logout")
                # row.operator("test.token")

                # col = self.layout.box().column()
                # img = bpy.data.images.load("//dexr_logo_white_smaller.png", check_existing=True) # load img from disk
                # # img = bpy.data.images['test2.png'] # load from within blend file
                # texture = bpy.data.textures.new(name="previewTexture", type="IMAGE")
                # texture.image = img
                # tex = bpy.data.textures['previewTexture']
                # tex.extension = 'CLIP'  #EXTEND # CLIP # CLIP_CUBE # REPEAT # CHECKER
                # col.template_preview(self.tex) # if tex is a variable in the same class
                # # or
                # # col.template_preview(textures[0])
            else:
                row = layout.row()
                row.scale_y = 3.0
                row.operator("api.needsdatarefresh")

        else:
            if AUTH0_PollCounter == 0:
                row = layout.row()
                row.scale_y = 3.0
                row.operator("api.authenticate")
            else:
                row = layout.row()
                layout.label(text="Please continue authentication in browser")
                layout.label(text="if your browser didn't open, go to:")
                layout.label(text=" https://dexr.eu.auth0.com/activate")
                layout.label(text=f" user code: {bpy.context.scene.LastKnownDeviceUserCode}")
                layout.label(text="")
                row = layout.row()
                row.enabled = False
                row.prop(context.scene,"RemainingAuthenticationTime",text="time remaining:")

class Simplified_Panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "| Step 2 |--> Sync to Dexr"
    bl_idname = "SCENE_PT_layout_SimplifiedPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DEXR'

    @classmethod
    def poll(self, context):
        scene = context.scene
        global NeedsAuthRefresh
        return Authenticated() and not NeedsAuthRefresh

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        asset = scene.AssetDefinition
        settings = scene.AddonSettings
        view = bpy.context.view_layer.active_layer_collection
        collection = view.collection
        # layout.label(text="")
        asset2 = collection.Asset
        # layout.label(text="Warning: !")

        row = layout.row()
        row.label(text=f'How this addon works:', icon='INFO')
        col = layout.column(align=True)
        box =  col.box()
        box_select = box.box()
        # box_select.label(text=f' Name your collection! ', icon='INFO')
        box_select.label(text=f'Blender objects can be organized in collections. ')
        box_select.label(text=f'Each collection will be converted to 1 DEXR library asset.')
        box_select.label(text=f'Start by selecting a collection, double-check the name')
        box_select.label(text=f' & hit Sync!')

        row = layout.row()
        row.label(text=f'')
        row = layout.row()
        row.prop(view,"name",text="name")
        row = layout.row()
        row.enabled = False
        row.prop(collection,"assetSpaceName",text="space")
        row = layout.row()
        row.enabled = False
        row.prop(collection,"assetID",text="DEXR id")
        if not bpy.context.scene.AdminSettings.production:
            row = layout.row()
            row.enabled = False
            row.prop(collection,"assetIDDevelopment",text="DEXR dev id")




        row = layout.row()
        row.scale_y = 6.0
        row.enabled = (GetAssetName() != "Scene Collection")
        row.operator("addon.completeflow")


        col = layout.column(align=True)
        box =  col.box()
        row = layout.row()
        row.operator("help.toggleguides")
        row = layout.row()
        row.enabled = HasAssetId()
        row.operator("help.openexplorer")
        row = layout.row()
        row.operator("help.documentation")



        # row = layout.row()
        # row.prop(asset,"name")
        # row = layout.row()
        # row.enabled = False
        # row.prop(collection,"assetID",text="id")
        # row = layout.row()
        # row.prop(asset2,"type")
        # row = layout.row()
        # row.scale_y = 2.0
        # row.enabled = (GetAssetId() == "") and (GetAssetName() != "Scene Collection")
        # row.operator("api.registerasset")


class Main_Panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "1.Register your asset"
    bl_idname = "SCENE_PT_layout_DexrAssetManager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DEXR'

    @classmethod
    def poll(self, context):
        scene = context.scene
        return not scene.AddonSettings.AutomaticMode

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        asset = scene.AssetDefinition
        settings = scene.AddonSettings
        view = bpy.context.view_layer.active_layer_collection
        collection = view.collection
        # layout.label(text="")
        asset2 = collection.Asset
        # layout.label(text="Warning: !")

        # row = layout.row()
        # row.label(text=f'How this addon works:', icon='INFO')
        # col = layout.column(align=True)
        # box =  col.box()
        # box_select = box.box()
        # # box_select.label(text=f' Name your collection! ', icon='INFO')
        # box_select.label(text=f'Blender objects can be organized in collections. ')
        # box_select.label(text=f'Each collection will be converted to 1 library asset')
        # box_select.label(text=f'in your Dexr Library. Start by giving your collection')
        # box_select.label(text=f'the name of your desired asset and hit Sync!')

        row = layout.row()
        row.prop(view,"name",text="name")
        # row = layout.row()
        # row.prop(asset,"name")
        row = layout.row()
        row.enabled = False
        row.prop(collection,"assetID",text="id")
        row = layout.row()
        row.prop(asset2,"type")
        row = layout.row()
        row.scale_y = 2.0
        row.enabled = (GetAssetId() == "") and (GetAssetName() != "Scene Collection")
        row.operator("api.registerasset")


        # row.scale_y = 1.0
        # row.operator("generator.guid")
        # row.values(bpy.context.view_layer.active_layer_collection.collection["assetID"])
        # Big render button
        # layout.label(text="Big Button:")

class Second_Panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "2.Generate your files"
    bl_idname = "SCENE_PT_layout_2"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DEXR'

    @classmethod
    def poll(self, context):
        scene = context.scene
        return not scene.AddonSettings.AutomaticMode

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        asset = scene.AssetDefinition
        settings = scene.AddonSettings

        row = layout.row()
        row.scale_y = 3.0
        row.operator("generator.generatethumbnail")
        row = layout.row()
        row.scale_y = 3.0
        row.operator("generator.model")
        row = layout.row()
        row.scale_y = 1.0
        row.operator("help.openexplorer")

        layout.label(text="Settings")
        # row = layout.row()
        # row.prop(settings, "useSelected")
        row = layout.row()
        row.enabled = False
        row.prop(settings, "UseCurrentCollection")
        row = layout.row()
        row.prop(settings, "resetPivot")
        row = layout.row()
        row.prop(settings, "CompressToJPEG")

class Third_Panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "3.Upload your files"
    bl_idname = "SCENE_PT_layout_3"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DEXR'

    @classmethod
    def poll(self, context):
        scene = context.scene
        return not scene.AddonSettings.AutomaticMode

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        asset = scene.AssetDefinition
        settings = scene.AddonSettings

        view = bpy.context.view_layer.active_layer_collection
        collection = view.collection

        # layout.label(text="3. Upload your files to DEXR")

        row = layout.row()
        row.prop(collection,"ClientSpace",text="Space")
        row = layout.row()
        row.scale_y = 2.0
        row.operator("api.uploadthumbnailasset")

        row = layout.row()
        row.scale_y = 2.0
        row.operator("api.uploadthreedmodel")

        row = layout.row()
        row.scale_y = 2.0
        row.operator("api.uploadtextures")

class Fourth_Panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "Help"
    bl_idname = "SCENE_PT_layout_4"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DEXR'

    @classmethod
    def poll(self, context):
        scene = context.scene
        return not scene.AddonSettings.AutomaticMode

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.operator("gltfviewer.openbrowser")
        layout.label(text="Naming scheme:")
        layout.label(text="category_type_name_size")

        # sublayout = layout.box()
        # # row.alignment = 'EXPAND'
        # sublayout.label(text="category_type_name_sizecategory_type_name_size")
        # sublayout.label(text="category_type_name_size")
        # sublayout.label(text="category_type_name_size")

        # layout.separator()
        # layout.label(text="category_type_name_size")

class Admin_Panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "ADMIN PANEL"
    bl_idname = "SCENE_PT_layout_Admin"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DEXR'

    @classmethod
    def poll(self, context):
        scene = context.scene
        return scene.UserSettings.isAdmin

    def draw(self, context):
        layout = self.layout
        settings = context.scene.AdminSettings

        row = layout.row()
        row.operator("settings.togglesimplepro")

        row = layout.row()
        row.label(text=f'')
        col = layout.column(align=True)
        box =  col.box()
        col = layout.column(align=True)

        row = layout.row()
        row.prop(settings, "publicOrPrivate")
        row = layout.row()
        row.enabled = False
        row.prop(settings, "production")
        row = layout.row()
        row.operator("auth.switchtoproduction")
        row.operator("auth.switchtodevelopment")
        row = layout.row()
        row.operator("generator.batchallcollections")
        row = layout.row()
        row.operator("generator.batchgetallassetmetadata")
        row = layout.row()
        row.operator("api.getassetdata")
        row = layout.row()
        row.operator("api.getspaces")
        row = layout.row()
        row.enabled = HasAssetId()
        row.operator("api.moveasset")
        row = layout.row()
        row.operator("help.maketexturesunique")



        row = layout.row()
        row.label(text=f'')
        col = layout.column(align=True)
        box =  col.box()
        col = layout.column(align=True)

        scene = context.scene
        index = scene.SelectedSpace
        if not HasAssetId():
            layout.label(text="assetCollections")
            # if len(bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].assetCollections) != 0:
            draw_ui_list(
                layout,
                context,
                list_path=f"scene.UserSettings.spaces[{index}].assetCollections",
                active_index_path="scene.SelectedAssetGroup",
                unique_id="assetCollections_id"
            )



        layout.label(text="Environments")
        row = layout.row()
        row.operator("api.getenvironments")
        draw_ui_list(
            layout,
            context,
            list_path=f"scene.DexrEnvironments",
            active_index_path="scene.SelectedDexrEnvironment",
            unique_id="environmentsList_id"
        )
        row = layout.row()
        row.prop(scene, "NewEnvironmentName")
        row = layout.row()
        row.operator("api.createenvironment")



class METADATAPANEL(bpy.types.Panel):
    bl_label = "METADATA"
    bl_idname = "SCENE_PT_layout_METADATAPANEL"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DEXR'

    def __init__(self):
        safecheckInteractables()
        # update_AssetStates_active_index()
        bpy.types.Panel.__init__(self)

    @classmethod
    def poll(self, context):
        return True

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        view = bpy.context.view_layer.active_layer_collection
        collection = view.collection
        asset = collection.Asset


        item = collection.Interactables[collection.Interactables_active_index]
        resultingState = collection.AssetStates[collection.AssetStates_active_index]

        row = layout.row()
        row.scale_y = 3.0
        row.operator("api.getassetdata")
        row.operator("api.updateassetdata")

        drawCustomDivider(layout)

        layout.label(text="Asset Metadata")
        row = layout.row()
        row.prop(asset,"type")
        row = layout.row()
        row.prop(asset,"title")
        row = layout.row()
        row.enabled = False
        row.prop(asset,"id")
        row = layout.row()
        row.prop(asset,"isVisibleInCatalog",expand=True)

        drawCustomDivider(layout)

        layout.label(text="Resulting States")
        draw_ui_list(
            layout,
            context,
            list_path="collection.AssetStates",
            active_index_path="collection.AssetStates_active_index",
            unique_id="AssetStates_id"
        )
        row = layout.row()
        row.prop(resultingState,"id")
        row = layout.row()
        row.prop(resultingState,"title")

        layout.label(text="MeshChanges")
        index= collection.AssetStates_active_index

        draw_ui_list(
            layout,
            context,
            list_path=f"collection.AssetStates[{index}].changes",
            active_index_path="collection.AssetMeshChanges_active_index",
            unique_id="AssetMeshChanges_id"
        )

        if len(resultingState.changes) > 0:
            resultingMeshChange = resultingState.changes[collection.AssetMeshChanges_active_index]
            row = layout.row()
            row.prop(resultingMeshChange,"type")
            row = layout.row()
            col = layout.column()
            row = col.row(align=True)
            row.prop(resultingMeshChange,"targetName")
            row.operator("picker.meshchangeobject", text="", icon='EYEDROPPER')
            layout.separator()
            box = layout.box()
            if "type"in resultingMeshChange:
                if  resultingMeshChange["type"] == 0:#"changeTransform":
                    if "transform" in resultingMeshChange:
                        row = box.row(align=True)
                        if "durationInMilliseconds" in resultingMeshChange: row.prop(resultingMeshChange,"durationInMilliseconds",text="transition time",expand=False)
                        transform = resultingMeshChange["transform"]
                        if "position" in transform:
                            row = box.row()
                            row.prop(resultingMeshChange.transform,"position")
                        if "eulerRotation" in transform:
                            row = box.row()
                            row.prop(resultingMeshChange.transform,"eulerRotation")
                        if "scale" in transform:
                            row = box.row()
                            row.prop(resultingMeshChange.transform,"scale")
                if resultingMeshChange["type"] == 1:
                    row = box.row()
                    row.prop(resultingMeshChange,"isVisible")
                elif resultingMeshChange["type"] == 2:
                    row = box.row(align=True)
                    row.prop(resultingMeshChange,"durationInMilliseconds",text="transition time",expand=False)
                    row = box.row()
                    row.prop(resultingMeshChange,"materialSlot")
                    row = box.row()
                    row.prop(resultingMeshChange,"propertyName")
                elif resultingMeshChange["type"] == 3:
                    row = box.row()
                    row.prop(resultingMeshChange,"animationName")

            row = layout.row()
            row.scale_y = 3.0
            row.operator("preview.state")

            # ob = context.object
            # layout.use_property_split = True
            # col = layout.column()
            # row = col.row(align=True)
            # row.prop(ob, "location")
            # row.use_property_decorate = False
            # row.prop(ob, "lock_location", text="", emboss=False, icon='DECORATE_UNLOCKED')






        row = layout.row()
        # row.prop(resultingMeshChange.transform,"position")
        # new.materialSlot = s.materialSlot
        # new.propertyName = s.propertyName
        # new.isVisible = s.isVisible
        # new.animationName = s.animationName

        drawCustomDivider(layout)


        row = layout.row()
        layout.label(text="Interactables")
        draw_ui_list(
            layout,
            context,
            list_path="collection.Interactables",
            active_index_path="collection.Interactables_active_index",
            unique_id="Interactables_id",
        )

        row = layout.row()
        row.prop(item,"title")
        row = layout.row()
        row.prop(item,"id")
        row = layout.row()
        row.prop(item,"targetName")
        row = layout.row()
        row.prop(item,"initialState")
        row = layout.row()

        layout.label(text="Interactable States")
        draw_ui_list(
            layout,
            context,
            list_path="collection.Interactables",
            active_index_path="collection.Interactables_active_index",
            unique_id="InteractableStates_id",
        )


# =============================================================================================================================================================
#                       FUNCTIONS
# =============================================================================================================================================================

def Initialize():
    Load_usersettings_from_file()

@persistent
def load_pre_handler(dummy):
    global IsInitializing
    IsInitializing = False
    print("event: LOAD PRE is triggered")
    print(f"IsInitializing is {IsInitializing}")

@persistent
def load_post_handler(dummy):
    # bpy.app.handlers.load_post.clear()
    # for handler in bpy.app.handlers.load_post:
    #         bpy.app.handlers.load_post.remove(handler)
    # global IsInitializing
    # print(f"IsInitializing pre if is {IsInitializing}")
    # if(IsInitializing == False):
    #     IsInitializing = True
    print(f"IsInitializing is {IsInitializing}")
    print("Event: load_post", bpy.data.filepath)
    print("----------------------")
    print("registering DEXR ADDON")
    settings = bpy.context.scene.AdminSettings

    global APIURL_baseUrl
    APIURL_baseUrl = APIURL_Production if settings.production else APIURL_Development
    print(APIURL_baseUrl)

    if not bpy.app.timers.is_registered(Initialize):bpy.app.timers.register(Initialize, first_interval=0.5)


def Init():
    if "AuthenticationToken" in bpy.context.scene:
        global authHeader
        authHeader = {'Authorization':f'Bearer {bpy.context.scene["AuthenticationToken"]}'}
    #     if bpy.context.scene.AuthenticationToken == "":
    #         Initialize()
    # else:
    #     Initialize()
def UpdateAssetStatesDataTest(self,context):
    c = bpy.context.view_layer.active_layer_collection.collection
    change = c.AssetStates[c.AssetStates_active_index].changes[c.AssetMeshChanges_active_index]
    safeDataCheckSingleMeshChange(change)
    UpdateMeshChangeName()

def safeDataCheckSingleMeshChange(change):

    if not "type" in change:
        change.type = '0'
        change.durationInMilliseconds = 330
    if change["type"] == 0:
        if not "transform" in change or not "position" in change.transform:
            change.transform.position = mathutils.Vector((0,0,0))
            change.transform.eulerRotation =  mathutils.Vector((0,0,0))
            change.transform.scale =  mathutils.Vector((0,0,0))
    if change["type"] == 1:
        if not "isVisible" in change:
            change.isVisible = False



def UpdateMeshChangeName():
    c = bpy.context.view_layer.active_layer_collection.collection
    change = c.AssetStates[c.AssetStates_active_index].changes[c.AssetMeshChanges_active_index]
    change.name = f"{c.AssetMeshChanges_active_index} - {GetStringFromMeshChangeEnum(change.type)} - {change.targetName}"

def update_AssetStates_active_index(self,context):
    # updateDataFromUI()
    # updateAssetMeshChangesList()
    print("missing update")
    bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges_active_index = 0

    # bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges = bpy.context.view_layer.active_layer_collection.collection.AssetStates[bpy.context.view_layer.active_layer_collection.collection.AssetStates_active_index].changes

    #  if len(bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges) == 0: bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges.add()

def PickMeshChangeObject():
    print("picking object")
    c = bpy.context.view_layer.active_layer_collection.collection
    change = c.AssetStates[c.AssetStates_active_index].changes[c.AssetMeshChanges_active_index]
    change.targetName = bpy.context.active_object.name
    UpdateMeshChangeName()

def ToggleState():
    print("doing meshChanges")
    c = bpy.context.view_layer.active_layer_collection.collection
    change = c.AssetStates[c.AssetStates_active_index].changes[c.AssetMeshChanges_active_index]

    sign = 1.0
    if change.isApplied:
        sign = -1.0

    obj = bpy.context.scene.objects.get(change.targetName)
    if obj:
        if change.type == '0':
            # obj = bpy.data.objects[change.targetName]
            obj.rotation_euler.rotate ( Euler((math.radians(change.transform.eulerRotation[0]*sign), math.radians(change.transform.eulerRotation[1]*sign), math.radians(change.transform.eulerRotation[2]*sign)), 'XYZ') )
            obj.location.xyz += mathutils.Vector(change.transform.position*sign)
            obj.scale += mathutils.Vector(change.transform.scale*sign)
            change.isApplied = not change.isApplied

    # bpy.data.objects[change.targetName].select_set(True)

    # bpy.data.objects["Cube"].select_set(True)
    # # to select the object in the 3D viewport,

    # current_state = bpy.data.objects["Cube"].select_get()
    # # retrieving the current state

    # # this way you can also select multiple objects

    # bpy.context.view_layer.objects.active = bpy.data.objects['Sphere']
    # # to set the active object

    # additionally you can use
    # bpy.context.scene.objects.active = bpy.data.objects['Sphere.017']
    # to make it the active selected object



    # from mathutils import Euler
    # obj.rotation_euler = Euler((0.3, 0.3, 0.4), 'XYZ')
    # bpy.context.scene.objects[""].location.xyz = ...

def updateAssetMeshChangesList():
    #DEPRECATED, I FOUND A BETTER WAY
    bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges_active_index = 0
    bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges.clear()
    for s in bpy.context.view_layer.active_layer_collection.collection.AssetStates[bpy.context.view_layer.active_layer_collection.collection.AssetStates_active_index].changes:
        new = bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges.add()
        new.type = s.type
        new.durationInMilliseconds = s.durationInMilliseconds
        new.targetName = s.targetName
        if new.type == "0":
            transform = new.transform
            transform.position = s.transform.position
            transform.eulerRotation = s.transform.eulerRotation
            transform.scale = s.transform.scale
            # print("position: " + str(new.transform.position))
        new.materialSlot = s.materialSlot
        new.propertyName = s.propertyName
        new.isVisible = s.isVisible
        new.animationName = s.animationName
        for e in MeshChangeTypeEnumValues:
            if e[0] == new.type:
                new.name = e[1]

def updateDataFromUI():
    print("update data from ui: TODO")

def GetStringFromMeshChangeEnum(i):
    for e in MeshChangeTypeEnumValues:
            if e[0] == i:
                return e[1]

def safecheckInteractables():
    if len(bpy.context.view_layer.active_layer_collection.collection.Interactables) == 0: bpy.context.view_layer.active_layer_collection.collection.Interactables.add()
    if len(bpy.context.view_layer.active_layer_collection.collection.InteractableStates) == 0: bpy.context.view_layer.active_layer_collection.collection.InteractableStates.add()
    if len(bpy.context.view_layer.active_layer_collection.collection.InteractableMeshChanges) == 0: bpy.context.view_layer.active_layer_collection.collection.InteractableMeshChanges.add()
    if len(bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges) == 0: bpy.context.view_layer.active_layer_collection.collection.AssetMeshChanges.add()
    if len(bpy.context.view_layer.active_layer_collection.collection.AssetStates) == 0: bpy.context.view_layer.active_layer_collection.collection.AssetStates.add()


def drawCustomDivider(iLayout):
    row = iLayout.row()
    newColor = (0.699,0.165,0.095,0.5)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)
    row.template_node_socket(color=newColor)

def SaveExpiryFromToken():
    if "AuthenticationToken" in bpy.context.scene:
        if bpy.context.scene["AuthenticationToken"] != "":
            token = bpy.context.scene.AuthenticationToken
            splittoken = token.split(".")
            value = splittoken[1]
            if len(value) % 4:
                # not a multiple of 4, add padding:
                value += '=' * (4 - len(value) % 4)
            payload = base64.b64decode(value).decode('utf-8')
            jsonObject = json.loads(payload)
            bpy.context.scene.AuthenticationExpiryUnix = jsonObject["exp"]

def IsTokenValid():
    if "AuthenticationToken" in bpy.context.scene:
        if bpy.context.scene["AuthenticationToken"] != "":
            # print(splittoken)
            # payloadCoded = str(splittoken[1])
            # missing_padding = len(payloadCoded) % 4
            # if missing_padding:
            #     payloadCoded += b'='* (4 - missing_padding)
            token = bpy.context.scene.AuthenticationToken
            splittoken = token.split(".")
            value = splittoken[1]
            if len(value) % 4:
                # not a multiple of 4, add padding:
                value += '=' * (4 - len(value) % 4)
            payload = base64.b64decode(value).decode('utf-8')
            jsonObject = json.loads(payload)
            expiryTime = jsonObject["exp"]
            bIsTokenValid = datetime.datetime.utcnow().timestamp() < expiryTime
            #if(bIsTokenValid == False): UpdateAuthorizationToken("")
            return bIsTokenValid

    return False

# token = bpy.context.scene.AuthenticationToken
#     splittoken = token.split(".")
#     payload = base64.b64decode(splittoken[1]).decode('utf-8')
#     jsonObject = json.loads(payload)
#     expiryTime = jsonObject["exp"]
#     bIsTokenValid = datetime.datetime.utcnow().timestamp() < expiryTime
#     print(f"token validity is {bIsTokenValid}")
#     if(bIsTokenValid == False): UpdateAuthorizationToken("")
#     else: bpy.types.Scene.AuthenticationExpiryUnix =
#     return bIsTokenValid

def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

def UpdateAuthorizationToken(token):
    print("DEXR - Updating token")
    global AUTH0_PollCounter
    AUTH0_PollCounter = 0
    bpy.context.scene.AuthenticationToken = token
    global authHeader
    authHeader = {'Authorization':f'Bearer {bpy.context.scene.AuthenticationToken}'}
    SaveExpiryFromToken()
    if(token == ""):
        bpy.context.scene.UserSettings.name = ""
        bpy.context.scene.UserSettings.email = ""
        bpy.context.scene.UserSettings.isAdmin = False
    else:
        AUTH0API_GetUserInfo()
        if not bpy.app.timers.is_registered(API_GetSpacesForUser): bpy.app.timers.register(API_GetSpacesForUser, first_interval=0.5)

    Save_usersettings_file(token)
    CreateGuideLayer()

def GetAssetDir():
    filepath = bpy.data.filepath
    directory = bpy.path.abspath(os.path.dirname(filepath))
    finaldir = directory + f"\\Dexr_Asset_{GetAssetName()}\\"
    return finaldir

def convert_bytes(num):
    """
    this function will convert bytes to MB.... GB... etc
    """
    for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
        if num < 1024.0:
            return "%3.1f %s" % (num, x)
        num /= 1024.0

def getAssetExportFolderSize():
    dir = GetAssetDir()
    foldersize = sum( os.path.getsize(os.path.join(dirpath,filename)) for dirpath, dirnames, filenames in os.walk( dir ) for filename in filenames )
    print(f"size of folder {dir} is {convert_bytes(foldersize)}")
    return foldersize

def getNameAndId():
    fullname = GetAssetName() +"_" + GetAssetId()
    return fullname

def HasAssetId():
    if( GetAssetId() == "" or GetAssetId() is None):
        return False
    return True
def GetAssetId():
    # id = bpy.context.scene.AssetDefinition.id
    prod = bpy.context.scene.AdminSettings.production
    id = ""
    if prod:
        if "assetID" in bpy.context.view_layer.active_layer_collection.collection :
            id = bpy.context.view_layer.active_layer_collection.collection["assetID"]
    else:
        if "assetIDDevelopment" in bpy.context.view_layer.active_layer_collection.collection :
            id = bpy.context.view_layer.active_layer_collection.collection["assetIDDevelopment"]
    return id
def GetAssetType():
    assettype = AssetTypeEnumValues[0]
    if "type" in bpy.context.view_layer.active_layer_collection.collection.Asset:
        assettype =  bpy.context.view_layer.active_layer_collection.collection.Asset["type"]
    return assettype

def SetAssetId(iId):
    bpy.context.scene.AssetDefinition.id = iId

    prod = bpy.context.scene.AdminSettings.production
    if prod: bpy.context.view_layer.active_layer_collection.collection["assetID"] = iId
    else: bpy.context.view_layer.active_layer_collection.collection["assetIDDevelopment"] = iId
def Authenticated():
    if "AuthenticationToken" in bpy.context.scene:
        if bpy.context.scene["AuthenticationToken"] != "":
            return IsTokenValid()

    return False
def AuthenticatedWithMessageBox():
    if( not Authenticated()):
        ShowMessageBox( f"Login is not valid (anymore)","Authentication Failure")
        return False
    return True
def GetAssetName():
    # return bpy.context.scene.AssetDefinition.name
    return bpy.context.view_layer.active_layer_collection.collection.name
def GetClientSpace():
    client = "dexr"
    if "ClientSpace" in bpy.context.view_layer.active_layer_collection.collection :
        client = bpy.context.view_layer.active_layer_collection.collection["ClientSpace"]
    return client

def SetClientSpace(iId):
    bpy.context.view_layer.active_layer_collection.collection["ClientSpace"] = iId

def GetRegisteredAssetGroup():
    id = ""
    if "assetGroup" in bpy.context.view_layer.active_layer_collection.collection :
        id = bpy.context.view_layer.active_layer_collection.collection["assetGroup"]
    return id

def SetAssetGroup(iId):
    bpy.context.view_layer.active_layer_collection.collection["assetGroup"] = iId

def SetAssetGroupName(iId):
    bpy.context.view_layer.active_layer_collection.collection["assetGroupName"] = iId

def GetCurrentAssetSpace():
    id = ""
    if "assetSpace" in bpy.context.view_layer.active_layer_collection.collection :
        id = bpy.context.view_layer.active_layer_collection.collection["assetSpace"]
    return id

def SetAssetSpace(iId):
    bpy.context.view_layer.active_layer_collection.collection["assetSpace"] = iId

def GetTokenExpiryDateStamp():
    if "AuthenticationExpiryUnix" in bpy.context.scene:
        if bpy.context.scene["AuthenticationExpiryUnix"] != "":
            return datetime.datetime.fromtimestamp(bpy.context.scene.AuthenticationExpiryUnix)

    return datetime.datetime.now



def getAssetMetaDataJson():
    if "assetMetaData" in bpy.context.view_layer.active_layer_collection.collection:
        txt = bpy.context.view_layer.active_layer_collection.collection["assetMetaData"]
        return json.loads(txt)

def GetThumbnailFileName():
    thumbnail_scene = bpy.context.scene
    name = GetAssetId()+f"_{thumbnail_scene.render.resolution_x}x{thumbnail_scene.render.resolution_y}"
    return name


def Unregistered(iShowMessageBox):
    if( not Authenticated()):
        if(iShowMessageBox):ShowMessageBox( f"Login is not valid (anymore)","Authentication Failure")
        return False
    if( GetAssetId() == "" or GetAssetId() is None or GetAssetName() == "Scene Collection"):
        if GetAssetName() == "Scene Collection":
            if(iShowMessageBox):ShowMessageBox( f"Cannot use the Scene Collection. Please use another collection","Flow Failure")
        else:
            if(iShowMessageBox):ShowMessageBox( f"No Asset Id found. Please register your asset in step 1 first","Flow Failure")
        return True
    return False

def OpenFileExplorer():
    dir = CreateDir()
    webbrowser.open(os.path.dirname(dir))

def CreateDir():
    output_directory = os.path.dirname(GetAssetDir()+"\\textures\\")
    print(output_directory)
    os.makedirs(output_directory, exist_ok=True,)
    return output_directory

def isolate_active_collection(isolate: bool):
    #bpy.data.collections['My Collection'].hide_viewport = True
    bpy.context.view_layer.active_layer_collection.hide_viewport = False
    bpy.context.view_layer.active_layer_collection.collection.hide_render = False
    collections = bpy.context.view_layer.layer_collection.children
    collections = bpy.data.collections

    for collection in collections:
        if collection != bpy.context.view_layer.active_layer_collection.collection:
            collection.hide_viewport =  isolate
            collection.hide_render =  isolate

def apply_modifiers_on_obj(obj):
    ctx = bpy.context.copy()
    ctx['object'] = obj
    for _, m in enumerate(obj.modifiers):
        try:
            ctx['modifier'] = m
            bpy.ops.object.modifier_apply(ctx, modifier=m.name)
        except RuntimeError:
            print(f"Error applying {m.name} to {obj.name}, removing it instead.")
            obj.modifiers.remove(m)

    for m in obj.modifiers:
        obj.modifiers.remove(m)

def apply_all_modifiers_in_scene():
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            apply_modifiers_on_obj(obj)

def set_all_object_positions_to_Zero():
    # objectPositions.clear()
    # for obj in bpy.data.objects:
    #     objectPositions.append(obj.location)
    #     obj.location = (0,0,0)

    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            objectPositions[obj.name] = obj.location.copy()
            obj.location = (0,0,0)

def set_all_objects_positions_to_cached():
    # for index, obj in enumerate(bpy.data.objects):
    #     obj.location = objectPositions[index]


    for obj_name, saved_position in objectPositions.items():
        obj = bpy.data.objects.get(obj_name)
        if obj:
            obj.location = saved_position

def create_asset_id(bOverride: bool):
    if(GetAssetId() != "" or bOverride):
        id = str(uuid.uuid4())
        SetAssetId(id)

def generate_asset_jsonBodyForApi(asset_name):
    typeInt = GetAssetType()
    type = "mesh"
    if typeInt == 1:
        type = "item"
    data = {
        "assetToSave":{
            "type":"mesh",#f"{type}",
            "title": asset_name,
            "url": f"{asset_name}.gltf",
            "initialStateId": "default",
            "states": [{ "id": "default", "title": "default", "changes": [] }],
            "interactables": [],
            "thumbnailUri": f"{asset_name}.png",
            "isVisibleInCatalog": True,
            "assetCollectionId":bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].assetCollections[bpy.context.scene.SelectedAssetGroup].id
        }
    }
    print(data)
    return json.dumps(data)

def generate_Json_UpdateAsset(asset_name):
    c = bpy.context.view_layer.active_layer_collection.collection
    changes = c.AssetStates[c.AssetStates_active_index].changes
    # states = [{"id":"jeanine","title":"jos"},{"id":"paul","title":"kamehameha"}]
    # json.dumps
    # jsonChanges = []
    # json.dumps(c.AssetStates[c.AssetStates_active_index].changes[c.AssetMeshChanges_active_index])
    states = [ SerializeMeshState(x) for x in c.AssetStates]
    data = {
        "assetToUpdate":{
            "type":"mesh",
            "title": asset_name,
            "id": f"{GetAssetId()}",
            "url": f"{asset_name}.gltf",
            "initialStateId": "default",
            "states":states ,
            "interactables": [],
            "thumbnailUri": f"{asset_name}.png",
            "isVisibleInCatalog": True
        }
    }
    print(json.dumps(data))
    return ""# json.dumps(data)
def SerializeMeshState(iMeshState):
    changes = [SerializeMeshChange(x) for x in iMeshState.changes]
    data = {
        "title": iMeshState.title,
        "id": iMeshState.id,
        "changes": changes
    }
    return data
def SerializeMeshChange(iMeshChange):
    data = {
        "type":GetStringFromMeshChangeEnum(iMeshChange.type),
        "durationInMilliseconds":iMeshChange.durationInMilliseconds,
        "targetName":iMeshChange.targetName,
        "targetObjectId": "",
    }
    if "isVisible" in iMeshChange:
        visibilityParams =  {"isVisible": iMeshChange.isVisible}
        data.update(visibilityParams)
    return data

def GetUserSettingsPath():
    prod = bpy.context.scene.AdminSettings.production
    userdir = bpy.utils.resource_path('USER') # see note
    filename = "DEXR_UserSettings"+ ("" if  prod else "_dev")
    path_to_file = userdir + f"\{filename}.json"
    # print(path_to_file)

    # Ensure the output directory exists or create it
    output_directory = os.path.dirname(path_to_file)
    os.makedirs(output_directory, exist_ok=True)

    return path_to_file
def Save_usersettings_file(iToken):

    path_to_file = GetUserSettingsPath()

    settings = bpy.context.scene.UserSettings
    token = iToken
    data = {
        "name":settings.name,
        "email": settings.email,
        "accesstoken": base64.b64encode(token.encode('utf-8')).decode('utf-8'),
        "roles": f""
    }

    with open(path_to_file, "w") as out_file_obj:
        text = json.dumps(data)
        out_file_obj.write(text)

def Load_usersettings_from_file():
    print("loading user settings")

    path_to_file = GetUserSettingsPath()
    if not Path(path_to_file).exists():
        return
    with open(path_to_file, "r") as out_file_obj:
        # print(out_file_obj)
        data = json.load(out_file_obj)
        # print(data["accesstoken"])
        if(data != ""):
            UpdateAuthorizationToken(base64.b64decode(data["accesstoken"]).decode('utf-8'))

def generate_asset_json(file_location,asset_name):
    print("created json & save to dir: ")

    if bpy.context.active_object:
        bpy.ops.object.mode_set(mode="OBJECT")

    filename = getNameAndId()
    data = {
        "type":"mesh",
        "id": filename,
        "title": asset_name,
        "url": f"{asset_name}.gltf",
        "initialStateId": "default",
        "states": [{ "id": "default", "title": "default", "changes": [] }],
        "interactables": [],
        "thumbnailUri": f"{asset_name}.png",
    }

    path_to_file = file_location + f"{filename}.json"
    print(path_to_file)

    # Ensure the output directory exists or create it
    output_directory = os.path.dirname(path_to_file)
    os.makedirs(output_directory, exist_ok=True)

    with open(path_to_file, "w") as out_file_obj:
        text = json.dumps(data)
        out_file_obj.write(text)

    webbrowser.open(os.path.dirname(path_to_file))

def generate_thumbnail(output_thumbnail_path):

    # Ensure the output directory exists or create it
    CreateDir()

     # Store the current camera and scene settings
    original_camera = bpy.context.scene.camera
    original_scene = bpy.context.scene

    # Create a new scene for rendering the thumbnail
    # bpy.ops.scene.new(type='LINK_COPY')
    thumbnail_scene = bpy.context.scene

    # add a lighting setup
    bpy.ops.object.light_add(type='SUN', radius=1, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1),rotation=(math.radians(-33),math.radians(25),math.radians(-22)))
    bpy.context.object.data.energy = 6
    sun = bpy.context.object

    # Set up the camera and lighting for rendering in the thumbnail scene
    thumbnail_camera = bpy.data.cameras.new("ThumbnailCamera")
    thumbnail_camera_obj = bpy.data.objects.new("ThumbnailCamera", thumbnail_camera)
    thumbnail_camera.clip_start = 0.001

    thumbnail_scene.collection.objects.link(thumbnail_camera_obj)
    thumbnail_scene.camera = thumbnail_camera_obj

    # set up the environment
    thumbnail_scene.eevee.use_gtao = True
    thumbnail_scene.eevee.gtao_distance = 1
    thumbnail_scene.eevee.use_ssr = True
    thumbnail_scene.eevee.use_bloom = True
    bpy.context.scene.render.film_transparent = True



    # Place the camera and adjust its settings as needed
    thumbnail_camera_obj.rotation_euler = (1.2472, 0, math.radians(30))  # Rotate the camera if needed

     # Select all objects in the scene and frame them
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.view3d.camera_to_view_selected()
    distz = mathutils.Vector((0.0, 0.0, 0.01))
    rotationMAT = thumbnail_camera_obj.rotation_euler.to_matrix()
    rotationMAT.invert()
    zVector = distz @ rotationMAT
    thumbnail_camera_obj.location = thumbnail_camera_obj.location + zVector

    # Set the render resolution and output path for the thumbnail
    thumbnail_scene.render.resolution_x = 128
    thumbnail_scene.render.resolution_y = 128
    thumbnail_scene.render.image_settings.file_format = 'PNG'
    thumbnail_scene.render.filepath = output_thumbnail_path + GetAssetId() +f"_{thumbnail_scene.render.resolution_x}x{thumbnail_scene.render.resolution_y}"

    # Render the thumbnail
    bpy.ops.render.render(write_still=True)

    # Clean up the thumbnail scene and camera
    bpy.data.cameras.remove(thumbnail_camera)
    # bpy.data.objects['sun'].select_set(True)
    # bpy.ops.object.delete()
    bpy.data.objects.remove(sun,do_unlink=True)
    # bpy.data.scenes.remove(thumbnail_scene)

    # object_to_delete = bpy.data.objects[sun.]
    # bpy.data.objects.remove(object_to_delete, do_unlink=True)

    # Restore the original scene and camera
    #bpy.context.window.scene = original_scene
    original_scene.camera = original_camera

    # Save the thumbnail
    #bpy.ops.wm.save_as_mainfile(filepath=output_thumbnail_path)

    return output_thumbnail_path

def Export_thumbnail(context):
    #scene setup
    if context.scene.AddonSettings.UseCurrentCollection:
        isolate_active_collection(True)
    if context.scene.AddonSettings.resetPivot:
        set_all_object_positions_to_Zero()

    generate_thumbnail(GetAssetDir())

    #scene cleanup
    if context.scene.AddonSettings.UseCurrentCollection:
        isolate_active_collection(False)
    if context.scene.AddonSettings.resetPivot:
        set_all_objects_positions_to_cached()

def export_Active_Collection(context):
    CreateDir()
    name = GetAssetName()
    dir = GetAssetDir()
    # create_virtual_collection()

    #scene setup
    if context.scene.AddonSettings.UseCurrentCollection:
        isolate_active_collection(True)
    if context.scene.AddonSettings.resetPivot:
        set_all_object_positions_to_Zero()


    #generate necessary files
    # generate_asset_json(GetAssetDir(),context.scene.AssetDefinition.name)
    # generate_thumbnail(GetAssetDir())
    # export_to_gltf(f"{dir}+{name}+.gltf",name,context.scene.AddonSettings.UseCurrentCollection)
    export_to_gltf(dir,name,context.scene.AddonSettings.UseCurrentCollection, context.scene.AddonSettings.CompressToJPEG)


    #scene cleanup
    if context.scene.AddonSettings.UseCurrentCollection:
        isolate_active_collection(False)
    if context.scene.AddonSettings.resetPivot:
        set_all_objects_positions_to_cached()

    # cleanup_virtual_collection()

def export_to_gltf( path, filename, useActiveCollection, compressToJPEG):
    # bpy.ops.export_scene.gltf(filepath='', check_existing=True, export_import_convert_lighting_mode='SPEC', gltf_export_id='', export_format='GLB', ui_tab='GENERAL', export_copyright='', export_image_format='AUTO', export_texture_dir='', export_jpeg_quality=75, export_keep_originals=False, export_texcoords=True, export_normals=True, export_draco_mesh_compression_enable=False, export_draco_mesh_compression_level=6, export_draco_position_quantization=14, export_draco_normal_quantization=10, export_draco_texcoord_quantization=12, export_draco_color_quantization=10, export_draco_generic_quantization=12, export_tangents=False, export_materials='EXPORT', export_original_specular=False, export_colors=True, export_attributes=False, use_mesh_edges=False, use_mesh_vertices=False, export_cameras=False, use_selection=False, use_visible=False, use_renderable=False, use_active_collection_with_nested=True, use_active_collection=False, use_active_scene=False, export_extras=False, export_yup=True, export_apply=False, export_animations=True, export_frame_range=False, export_frame_step=1, export_force_sampling=True, export_animation_mode='ACTIONS', export_nla_strips_merged_animation_name='Animation', export_def_bones=False, export_hierarchy_flatten_bones=False, export_optimize_animation_size=True, export_optimize_animation_keep_anim_armature=True, export_optimize_animation_keep_anim_object=False, export_negative_frame='SLIDE', export_anim_slide_to_zero=False, export_bake_animation=False, export_anim_single_armature=True, export_reset_pose_bones=True, export_current_frame=False, export_rest_position_armature=True, export_anim_scene_split_object=True, export_skins=True, export_all_influences=False, export_morph=True, export_morph_normal=True, export_morph_tangent=False, export_morph_animation=True, export_morph_reset_sk_data=True, export_lights=False, export_nla_strips=True, will_save_settings=False, filter_glob='*.glb')
    print("exporting gltf")
    print(path)
    print(filename)
    if compressToJPEG:
        bpy.ops.export_scene.gltf(filepath=path+filename, export_format='GLTF_SEPARATE', use_active_collection=useActiveCollection, check_existing=False, use_active_scene=True,export_texture_dir="textures",export_apply=True,export_image_format='JPEG',export_jpeg_quality=100)
    else:
        bpy.ops.export_scene.gltf(filepath=path+filename, export_format='GLTF_SEPARATE', use_active_collection=useActiveCollection, check_existing=False, use_active_scene=True,export_texture_dir="textures",export_apply=True)


# filepath = bpy.data.filepath
# directory = bpy.path.abspath(os.path.dirname(filepath))
# finaldir = directory + "\\output\\thumbnails\\"
# filename = "test"
# print(finaldir)
# print(filepath)
# generate_thumbnail(finaldir,filename)

def FULLSYNC():
    if(not AuthenticatedWithMessageBox()): return
    print("starting Dexr assetsync")



    if(Unregistered(False)):
        if len(bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].assetCollections) == 0 :
            error = f"Create Asset failed. Please contact DEXR support with Error code: [MISSING ASSET COLLECTION]"
            print(error)
            ShowMessageBox(error,"Cannot create asset.")
            return
        else:
            API_RegisterAsset(False)

    tryExportActiveCollection()

    if(getAssetExportFolderSize() > 50000000): #MB
        ShowMessageBox(f"Your exported asset {convert_bytes(getAssetExportFolderSize())} while the current limit for DEXR is 50Mb. Please optimize your asset before uploading again.","Cannot upload")
        return

    if len(bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].assetCollections) == 0 :
        error = f"Upload failed. Please contact DEXR support with Error code: [MISSING ASSET COLLECTION]"
        print(error)
        ShowMessageBox(error,"Cannot upload")
        return

    Upload_All()

    if GetRegisteredAssetGroup() == "":
        assetgroup = None
        if len(bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].assetCollections) != 0 : assetgroup = bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].assetCollections[bpy.context.scene.SelectedAssetGroup].id
        if assetgroup is not None :
            API_MoveAssetToAssetGroup(GetAssetId(),assetgroup)


def API_RegisterAsset(iShowMessageBox):
    print("start create asset API call")
    data = generate_asset_jsonBodyForApi(GetAssetName())
    url = f"{APIURL_baseUrl}assets/"
    print(url)
    appheader = {'content-type': 'application/json' }
    r = requests.post(url,data=data,headers=authHeader|appheader|productHeader)
    if(not r.ok):
        if(iShowMessageBox):ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","registry failed")
        print(r.content)
        print(r.reason)
    else:
        if(iShowMessageBox):ShowMessageBox( f"registration succesful, response id is: {r.text}")
        SetAssetId(r.text)
        bpy.ops.wm.save_mainfile()

def AUTH0API_GetUserInfo():
    prod = bpy.context.scene.AdminSettings.production
    print("getting user info")
    url = "https://dev-dexr.eu.auth0.com/userinfo"
    produrl = "https://dexr.eu.auth0.com/userinfo"
    # SCOPE = "openid profile offline_access"
    appheader = {'content-type': 'application/json' }
    r = requests.get(produrl if prod else url,headers=authHeader|appheader)
    if(not r.ok):
        ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","Get data failed")
        print(r.content)
        print(r.reason)
    else:
        # ShowMessageBox( f"Get asset succesful, data is loaded")
        # print(r.text)
        jsonResponse = json.loads(r.text)
        bpy.context.scene.UserSettings.name =  jsonResponse["nickname"]
        bpy.context.scene.UserSettings.email =  jsonResponse["name"]
        print(jsonResponse["https://stage.dexr.eu/roles/"])
        userRoles = jsonResponse["https://stage.dexr.eu/roles/"]
        admin = False
        for role in userRoles:
            if(role == "Dexr Admin"):
                admin = True
        bpy.context.scene.UserSettings.isAdmin = admin


        # bpy.context.view_layer.active_layer_collection.collection["assetMetaData"] = json.dumps(result)
        # jsonObject = json.loads(result)
        # print(jsonObject["result"][0])
        # loadAssetData()


def AUTH0API_GetDeviceCode():
    prod = bpy.context.scene.AdminSettings.production
    print("fetching device code")
    url = "https://dev-dexr.eu.auth0.com/oauth/device/code"
    produrl = "https://dexr.eu.auth0.com/oauth/device/code"
    # url = "https://dev-dexr.eu.auth0.com/oauth/token"
    SCOPE = "openid profile offline_access"
    form_data = {
        "audience": AUTH0_AUDIENCE_PROD if prod else AUTH0_AUDIENCE_DEV,
        "scope": SCOPE,
        "client_id": base64.b64decode(AUTH0_CLIENT_ID_PROD).decode('utf-8') if prod else base64.b64decode(AUTH0_CLIENT_ID_DEV).decode('utf-8')
    }
    appheader = {'content-type': 'application/x-www-form-urlencoded' }
    r = requests.post(produrl if prod else url,data=form_data,headers=appheader)
    jsonResponse = json.loads(r.text)
    if(not r.ok):
        ShowMessageBox( f"code {r.status_code} reason: {r.reason}","reason")
    else:
        ShowMessageBox( "got a device code!")
        bpy.context.scene.LastKnownDeviceUserCode = jsonResponse["user_code"]
        print(r.text)
        webbrowser.open(json.loads(r.text)["verification_uri_complete"])
        bpy.app.timers.register(functools.partial(AUTH0API_PollAuthorizationWithDeviceCode,json.loads(r.text)["device_code"]))

def AUTH0API_PollAuthorizationWithDeviceCode(iDeviceCode):
    print("polling")
    prod = bpy.context.scene.AdminSettings.production
    global AUTH0_PollCounter
    AUTH0_PollCounter += 1
    print(AUTH0_PollCounter)
    if AUTH0_PollCounter == AUTH0_PollCountMax:
        AUTH0_PollCounter = 0
        return None

    url = "https://dev-dexr.eu.auth0.com/oauth/token"
    produrl = "https://dexr.eu.auth0.com/oauth/token"
    form_data = {
        "device_code": iDeviceCode,
        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
        "client_id": base64.b64decode(AUTH0_CLIENT_ID_PROD).decode('utf-8') if prod else base64.b64decode(AUTH0_CLIENT_ID_DEV).decode('utf-8')
    }
    appheader = {'content-type': 'application/x-www-form-urlencoded' }
    r = requests.post(produrl if prod else url,data=form_data,headers=appheader)
    jsonResponse = json.loads(r.text)
    if(not r.ok):
        error = jsonResponse["error"]
        if(error == "authorization_pending"):
            print( f"code {r.status_code} reason: {r.reason} text= {error}")
            bpy.context.scene.RemainingAuthenticationTime = (AUTH0_PollCountMax-AUTH0_PollCounter)*5
            return 5
        else:
            ShowMessageBox("Authorization failed")
            print("Authorization failed")
            AUTH0_PollCounter = 0
            return None
    else:
        ShowMessageBox( "Authorization success!")
        # print(r.text)
        UpdateAuthorizationToken(jsonResponse["access_token"])



def API_GetAssetData():
    if(not HasAssetId()): return
    print("Fetching Asset Data")
    result = ""
    url = f"{APIURL_baseUrl}assets/{GetAssetId()}"
    print(url)
    appheader = {'content-type': 'application/json' }
    r = requests.get(url,headers=authHeader|appheader|productHeader)
    if(not r.ok):
        # ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","Get data failed")
        print("can't get Asset Data")
        print(r.content)
        print(r.reason)
    else:
        # ShowMessageBox( f"Get asset succesful, data is loaded")
        result = json.loads(r.text)#["result"][0]
        bpy.context.view_layer.active_layer_collection.collection["assetMetaData"] = json.dumps(result)
        loadAssetData()
        API_GetAssetCollectionData()

def API_GetAssetCollectionData():
    print("Fetching AssetCollection Data")
    result = ""
    url = f"{APIURL_baseUrl}assetcollections/{GetRegisteredAssetGroup()}"
    print(url)
    appheader = {'content-type': 'application/json' }
    r = requests.get(url,headers=authHeader|appheader|productHeader)
    if(not r.ok):
        # ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","Get data failed")
        print("-----------------")
        print("can't get assetCollection Data")
        print(r.content)
        print(r.reason)
    else:
        # ShowMessageBox( f"Get asset succesful, data is loaded")
        print("-----------------")
        print("getting assetCollection Data succesful")
        result = json.loads(r.text)
        SetAssetSpace(result["spaceId"])
        SetAssetGroupName(result["name"])
        # bpy.context.view_layer.active_layer_collection.collection["assetMetaData"] = json.dumps(result)
        # loadAssetData()

def API_GetSpacesForUser():
    print("Fetching spaces")
    result = ""
    url = f"{APIURL_baseUrl}spacesForUser/"
    print(url)
    appheader = {'content-type': 'application/json' }
    r = requests.get(url,headers=authHeader|appheader|productHeader)
    if(not r.ok):
        # ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","Get spaces failed")
        print("failed to get spaces")
        print(r.content)
        print("reason:")
        print(r.reason)
        global NeedsAuthRefresh
        NeedsAuthRefresh = True

    else:
        print( f"Get spaces succesful, data is loaded")
        result = json.loads(r.text)["result"]
        # print(result)
        bpy.context.scene.UserSettings.spaces.clear()
        for entry in result:
            newSpace = bpy.context.scene.UserSettings.spaces.add()
            newSpace.name = entry["name"]
            newSpace.id = entry["id"]
            newSpace.ownerId = entry["ownerId"]
            for id in entry["assetCollections"]:
                newAssetGroup = newSpace.assetCollections.add()
                newAssetGroup.id = id
                newAssetGroup.name = id
                print(id)


def API_UpdateAssetData():
    print("sending update API call to server")
    data = generate_Json_UpdateAsset(GetAssetName())
    url = f"{APIURL_baseUrl}{APIURL_UpdateAsset}{GetAssetId()}"
    print(url)
    appheader = {'content-type': 'application/json' }
    r = requests.put(url,data=data,headers=authHeader|appheader|productHeader)
    if(not r.ok):
        ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","Upload failed")
        print(r.content)
        print(r.reason)
    else:
        ShowMessageBox( f"update succesful, responseis: {r.text}")

def API_GetEnvironments():
    print("Fetching environments")
    result = ""
    url = f"{APIURL_baseUrl}environments/"
    # print(url)
    appheader = {'content-type': 'application/json' }
    r = requests.get(url,headers=authHeader|appheader|productHeader)
    if(not r.ok):
        ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","Get environments failed")
        print("failed to get spaces")
        print(r.content)
        print("reason:")
        print(r.reason)
    else:
        print( f"Get environments succesful, data is loaded")
        result = json.loads(r.text)["result"]
        print(result)
        bpy.context.scene.DexrEnvironments.clear()
        for entry in result:
            newData = bpy.context.scene.DexrEnvironments.add()
            newData.name = entry["title"]
            newData.id = entry["id"]
def API_CreateNewEnvironment(iShowMessageBox = True):
    body = {
    "environmentToSave": {
        "title": f"{bpy.context.scene.NewEnvironmentName}"
        }
    }
    data = json.dumps(body)
    url = f"{APIURL_baseUrl}environments/"
    appheader = {'content-type': 'application/json' }
    r = requests.post(url,data=data,headers=authHeader|appheader|productHeader)
    if(not r.ok):
        if iShowMessageBox: ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","api call failed")
        print(r.content)
        print(r.reason)
    else:
        if iShowMessageBox: ShowMessageBox( f"create environment succesful")
        API_GetEnvironments()


def API_MoveAssetToAssetGroup(iAssetToMoveId,iAssetGroupId, iShowMessageBox = False):
    print("Moving asset to another assetgroup")
    data = {
    "assetCollectionId": iAssetGroupId,
    "assetsToMove": [iAssetToMoveId]
    }
    formattedData = json.dumps(data)
    url = f"{APIURL_baseUrl}{APIURL_MoveAsset}"
    # print(url)
    # print (formattedData)
    appheader = {'content-type': 'application/json' }
    r = requests.post(url,data=formattedData,headers=authHeader|appheader|productHeader)
    if(not r.ok):
        if iShowMessageBox: ShowMessageBox( f"code {r.status_code} reason: {r.reason} __ {r._content}","api call failed")
        print(r.content)
        print(r.reason)
    else:
        if iShowMessageBox: ShowMessageBox( f"move asset succesful")
        SetAssetSpace(bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].id)
        bpy.context.view_layer.active_layer_collection.collection["assetSpaceName"] = bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].name
        SetAssetGroup(iAssetGroupId)

def clearAssetData(iCollection):
    iCollection.Interactables.clear()
    iCollection.AssetStates.clear()
    iCollection.AssetMeshChanges.clear()
    iCollection.InteractableStates.clear()
    iCollection.InteractableMeshChanges.clear()
    iCollection.Interactables_active_index = 0
    iCollection.InteractableStates_active_index = 0
    iCollection.AssetStates_active_index = 0
    iCollection.AssetMeshChanges_active_index = 0
    iCollection.InteractableMeshChanges_active_index = 0



def loadAssetData():
    safecheckInteractables()

    view = bpy.context.view_layer.active_layer_collection
    collection = view.collection
    asset = collection.Asset
    Interactables = collection.Interactables
    clearAssetData(collection)
    assetJson = getAssetMetaDataJson()
    # print(assetJson)

    asset.title = assetJson["title"]
    asset.id = assetJson["id"]
    SetAssetGroup(assetJson["assetCollectionId"])
    return
    if  assetJson["type"] == "mesh": asset.type = '0'
    else: asset.type = '1'

    for JsonState in assetJson["states"]:
        newState = collection.AssetStates.add()
        newState.id = JsonState["id"]
        newState.title = JsonState["title"]
        newState.name = JsonState["title"]
        # print("printing a meshstate")
        # print(len(newState.changes))
        # newState.changes = MeshState["dd"]
        # print(JsonState)
        if "changes" in JsonState:
            # changes = newState["changes"]
            count = 0
            for JsonChange in JsonState["changes"]:
                # print("printing a meshChange")
                # print(JsonChange)
                newChange =  newState.changes.add()

                newChange.targetName = JsonChange["targetName"]
                if "durationInMilliseconds" in JsonChange: newChange.durationInMilliseconds = JsonChange["durationInMilliseconds"]
                #   items=[('0',"Transform",""),('1',"Visibility",""),('2',"Material",""),('3',"Animation","")]
                if  JsonChange["type"] == "changeTransform":
                        newChange.type = '0'
                        # print("position")
                        # print(JsonChange["transform"]["position"])
                        newChange.transform.position = JsonChange["transform"]["position"]
                        newChange.transform.eulerRotation = JsonChange["transform"]["eulerRotation"]
                        newChange.transform.scale = JsonChange["transform"]["scale"]
                elif JsonChange["type"] == "changeObjectVisibility":
                    newChange.type = '1'
                    newChange.isVisible = JsonChange["isVisible"]
                elif JsonChange["type"] == "changeMaterialProperty":
                    newChange.type = '2'
                    newChange.materialSlot = JsonChange["materialSlot"]
                    newChange.propertyName = JsonChange["propertyName"]
                elif JsonChange["type"] == "playAnimation":
                    newChange.type = '3'
                    newChange.animationName = JsonChange["animationName"]

                newChange.name = f"{count} - {GetStringFromMeshChangeEnum(newChange.type)} - {newChange.targetName}"
                count += 1








    for i in assetJson["interactables"]:
        newItem = Interactables.add()
        newItem.name = i["title"]
        newItem.title = i["title"]
        newItem.id = i["id"]
        newItem.targetName = i["targetName"]
        if "initialState" in i: newItem.initialState = i["initialState"]
        else: newItem.initialState = ""



    # item = collection.Interactables[collection.Interactables_active_index]
    # newItem.title =
def MakeTexturesUnique():
    print("making textures unique")
    selectedCollectionObjects = bpy.context.view_layer.active_layer_collection.collection.objects
    for obj in selectedCollectionObjects:
        for mat_slot in obj.material_slots:
            if mat_slot.material:
                if mat_slot.material.node_tree:
                #    print("material:" + str(mat_slot.material.name))
                   for x in mat_slot.material.node_tree.nodes:
                        if x.type=='TEX_IMAGE':
                           if x.image:
                            print(" texture: "+str(x.image.name))
                            if GetAssetId() not in x.image.name:
                                x.image.name += GetAssetId()
                                print(x.image.name)


        # bpy.data.images["Image_3_test"].name = "Image_3_test"



def create_virtual_collection():
    bpy.ops.wm.save_mainfile()
    selectedObjects = list(bpy.context.view_layer.active_layer_collection.collection.objects)
    selectedCollection = bpy.context.view_layer.active_layer_collection.collection.objects
    PipelineCollection = bpy.data.collections.new("PipelineCollection")
    bpy.context.scene.collection.children.link(PipelineCollection)
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[PipelineCollection.name]

    DuplicatedObjects.clear()
    for obj in selectedObjects:
        duplicate = duplicate_object(obj)
        # duplicate.name = obj.name
        DuplicatedObjects.append(duplicate)
        apply_modifiers_on_obj(duplicate)
        PipelineCollection.objects.link(duplicate)
        selectedCollection.unlink(duplicate)


def duplicate_object(obj):
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate(linked=False)
    duplicate = bpy.context.selected_objects[-1]
    duplicate.select_set(False)
    obj.select_set(False)
    duplicate.name = obj.name
    return duplicate

def cleanup_virtual_collection():
    print("cleanup")
    bpy.ops.wm.revert_mainfile()
    # for obj in PipelineCollection.objects:
    #     bpy.data.objects.remove(obj, do_unlink=True)

    # bpy.data.collections.remove(PipelineCollection)

def set_active_collection(collection_name):
    for collection in bpy.data.collections:
        if collection.name == collection_name:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[collection_name]
            break

def tryExportActiveCollection():
    print(GetAssetId())
    if(not Unregistered(False)):
        MakeTexturesUnique()
        Export_thumbnail(bpy.context)
        Export_model()

def Export_model():
    print("Starting Model export")
    export_Active_Collection(bpy.context)
    print("Export Completed")

def Upload_All():
    print("Starting Upload")
    API_UploadThumbnail(f"{GetThumbnailFileName()}.png",f"{GetAssetDir()}{GetThumbnailFileName()}.png",f"{GetThumbnailFileName()}.png")
    API_UploadModelFiles()
    API_UploadTextures()
    print("Upload complete")
    ShowMessageBox("Upload complete")

def BATCH_ExportAndUploadNextAsset():
    global Batch_current_index
    global collections_to_process

    if len(collections_to_process) == 0:
        collections_to_process = bpy.data.collections
    if Batch_current_index < len(collections_to_process):
        print(f"collections: processing {Batch_current_index+1} of {len(bpy.data.collections)}")
        collection_name = collections_to_process[Batch_current_index].name
        set_active_collection(collection_name)
        print(f"Processing collection: {collection_name}")
        Batch_current_index += 1
        BATCH_tryExportActiveCollection()
    else:
        print("All assets have been processed")
        Batch_current_index = 0
        collections_to_process = []

def BATCH_GetAllAssetMetaDataFromAssetId():
    global Batch_current_index
    global collections_to_process

    if len(collections_to_process) == 0:
        collections_to_process = bpy.data.collections
    if Batch_current_index < len(collections_to_process):
        print(f"collections: processing {Batch_current_index+1} of {len(bpy.data.collections)}")
        collection_name = collections_to_process[Batch_current_index].name
        set_active_collection(collection_name)
        print(f"Processing collection: {collection_name}")
        Batch_current_index += 1
        if(HasAssetId()): API_GetAssetData()
        BATCH_GetAllAssetMetaDataFromAssetId()
    else:
        print("All assets have been processed")
        Batch_current_index = 0
        collections_to_process = []

def BATCH_tryExportActiveCollection():
    print(GetAssetId())
    if(GetRegisteredAssetGroup() == ""):
        BATCH_ExportAndUploadNextAsset()
    else:
        if(not Unregistered(True)): BATCH_Export_model_auto()
        else: BATCH_ExportAndUploadNextAsset()

def BATCH_Export_model_auto():
    print("Starting Model export")
    export_Active_Collection(bpy.context)
    BATCH_on_export_complete()

def BATCH_on_export_complete():
    print("Export Completed")
    # Proceed to upload
    BATCH_upload_model_batched(BATCH_on_upload_complete)

def BATCH_upload_model_batched(callback):
    # Simulate the upload process

    API_UploadModelFiles()
    API_UploadTextures()
    # API_UploadThumbnail()
    print("Upload complete")
    callback()

def BATCH_on_upload_complete():
    print("Upload callback triggered")
    # Proceed to the next asset or finish
    BATCH_ExportAndUploadNextAsset()



# =====================================================
#                       API Calls
# =====================================================

def API_UploadThumbnail(iFilenameTarget,iFilepath,iFileName):
    print("start upload")
    print(iFilepath)
    print(iFileName)
    # png_file_path= "G:\My Drive\WORK\Kim Note Games\Dexr\Working files\Code\Addons\Dexr_Asset_22\\22_2872bafc-df8b-4709-8d3c-0f4e590e9cba_512x512.png"
    files = {"file": (iFileName, open(iFilepath, "rb"), "image/png"),}
    url = APIURL_baseUrl+APIURL_UploadAssetThumbnailUrl+iFilenameTarget
    r = requests.post(url,files=files,headers=authHeader|productHeader)
    if(not r.ok):
        ShowMessageBox( f"code {r.status_code} reason: {r.reason}","Upload failed")
    else:
        ShowMessageBox( "upload succesful")

def API_UploadTextures():
    print("start uploading textures")

    dirTarget = f"{GetAssetDir()}textures"
    print(dirTarget)
    if(not os.path.isdir(dirTarget)): return
    dir = os.listdir(dirTarget)
    for filename in dir:
        API_UploadTexture(filename,dirTarget+"\\"+filename)

def API_UploadTexture(iFileName, iFilepath):
    print(f"starting uploading {iFileName}")
    files = {"file": (iFileName, open(iFilepath, "rb"), "image/png"),}
    url = APIURL_baseUrl+APIURL_UploadTexturesUrl.replace("dexr",GetClientSpace())+iFileName
    print(url)
    r = requests.post(url,files=files,headers=authHeader|productHeader)
    if(not r.ok):
        print( f"code {r.status_code} reason: {r.reason}","Upload failed")
    else:
        print( f"upload {iFileName} succesful")

def API_UploadModelFiles():
    print("upload model")
    filePath = GetAssetDir()+GetAssetName()
    API_Upload(GetAssetName()+".gltf",filePath+".gltf","model/gltf+json")
    API_Upload(GetAssetName()+".bin",filePath+".bin","application/octet-stream")
# application/octet-stream
# model/gltf+json
def API_Upload(iFileName, iFilepath,iType):
    print(f"starting uploading {iFileName}")
    files = {"file": (iFileName, open(iFilepath, "rb"), iType),}
    url = APIURL_baseUrl+APIURL_UploadModelsUrl.replace("dexr",GetClientSpace())+iFileName
    r = requests.post(url,files=files,headers=authHeader|productHeader)
    if(not r.ok):
        print( f"code {r.status_code} reason: {r.reason}","Upload failed")
    else:
        print( f"upload {iFileName} succesful")


def moveToActiveLayer():
    obj = bpy.context.selected_objects[0]
    for collections in obj.users_collection:
        collections.objects.unlink(obj)
    # bpy.context.scene.collection.objects.unlink(obj)
    bpy.data.collections["DEXR_GUIDE"].objects.link(obj)
    #new_collection.objects.link(obj)
def CreateGuideLayer():
    if "DEXR_GUIDE" not in bpy.data.collections:
        new_collection = bpy.data.collections.new("DEXR_GUIDE")
        bpy.context.scene.collection.children.link(new_collection)
        bpy.data.collections["DEXR_GUIDE"].hide_select = True
        obj = bpy.ops.object.empty_add(type='SINGLE_ARROW', align='WORLD',rotation=(math.radians(180+71.45), 0, math.radians(30-360)), location=(1, -2, 1), scale=(1, 1, 1))
        moveToActiveLayer()
        obj = bpy.ops.object.empty_add(type='SINGLE_ARROW', align='WORLD',rotation=(math.radians(90), 0, 0), location=(0, -1, 0), scale=(1, 1, 1))
        moveToActiveLayer()
        obj = bpy.ops.object.empty_add(type='CIRCLE', align='WORLD',rotation=(math.radians(90.0),0,0), location=(0, 0, 0), scale=(1, 1, 1))
        moveToActiveLayer()
    #hide_viewport

def SetGuideCollectionVisibility(iIsvisible):
    bpy.data.collections["DEXR_GUIDE"].hide_viewport = iIsvisible
def ToggleGuideCollectionVisibility():
    if "DEXR_GUIDE" in bpy.data.collections:
        bpy.data.collections["DEXR_GUIDE"].hide_viewport = not bpy.data.collections["DEXR_GUIDE"].hide_viewport
    else:
        CreateGuideLayer()


# =====================================================
#                       MAIN CLASSES & OPERATORS
# =====================================================
class TEST_TOKEN(Operator):
    bl_idname = "test.token"
    bl_label = "debug access token"

    def execute(self, context):

        if "AuthenticationToken" in bpy.context.scene:
            token = bpy.context.scene.AuthenticationToken
            print(token)
            #padded = token + "="*divmod(len(token),4)[1]
            # decodedString = base64.urlsafe_b64decode(token)
            #decoded_token = base64.b64decode(padded.encode("utf-8")).decode("utf-8")
            #decoded_token
            # print(decodedString)
            # data = json.loads(decodedString)
            # data
            splittoken = token.split(".")
            print (splittoken)
            print ("---")
            print (splittoken[1])
            value = splittoken[1]
            if len(value) % 4:
                # not a multiple of 4, add padding:
                value += '=' * (4 - len(value) % 4)
            payload = base64.b64decode(value).decode('utf-8')
            print(payload)
            jsonObject = json.loads(payload)
            print(jsonObject["exp"])
            print(datetime.datetime.utcnow().timestamp())
            print(datetime.datetime.utcnow().timestamp() < jsonObject["exp"])
            print (datetime.datetime.fromtimestamp(jsonObject["exp"]))


        return {'FINISHED'}

class HELP_OPEN_GLTFVIEWER(Operator):
    bl_idname = "gltfviewer.openbrowser"
    bl_label = "Open GLTF viewer"

    def execute(self, context):
        webbrowser.open("https://gltf-viewer.donmccurdy.com/")
        return {'FINISHED'}

class HELP_TOGGLE_GUIDE(Operator):
    bl_idname = "help.toggleguides"
    bl_label = "Toggle Guide Gizmo"
    bl_description = "Dexr assets have a specific forward facing axis so all assets are uniform, indicated with the arrow. You can also see the angle in which the thumbnail will be generated. Toggle this visibility with this button."

    def execute(self, context):
        ToggleGuideCollectionVisibility()
        return {'FINISHED'}
class HELP_DOCUMENTATION(Operator):
    bl_idname = "help.documentation"
    bl_label = "Open Documentation"
    bl_description = "Open up the live documentation of Dexr Stage"

    def execute(self, context):
        webbrowser.open("http://help.dexr.eu/")
        return {'FINISHED'}
class GENERATE_ID(Operator):
    bl_idname = "generator.guid"
    bl_label = "generate"

    def execute(self, context):
        create_asset_id(True)
        return {'FINISHED'}

class HELP_EXPLORER(Operator):
    bl_idname = "help.openexplorer"
    bl_label = "Open file folder"
    bl_description = "Once you've generated files for this asset, opens up the file explorer to the files saved on your hard disk."

    def execute(self, context):
        OpenFileExplorer()
        return {'FINISHED'}
class SETTINGS_TOGGLESIMPLE(Operator):
    bl_idname = "settings.togglesimplepro"
    bl_label = "Toggle manual mode"

    def execute(self, context):
        context.scene.AddonSettings.AutomaticMode = not context.scene.AddonSettings.AutomaticMode
        return {'FINISHED'}
class UPLOAD_THUMBNAIL_ASSET(Operator):
    bl_idname = "api.uploadthumbnailasset"
    bl_label = "Upload Thumbnail"
    bl_description = "Upload your generated thumbnail. Feel free to do this as much as you want"

    def execute(self, context):
        if Unregistered(True): return {'FINISHED'}

        API_UploadThumbnail(f"{GetThumbnailFileName()}.png",f"{GetAssetDir()}{GetThumbnailFileName()}.png",f"{GetThumbnailFileName()}.png")
        return {'FINISHED'}
class UPLOAD_3DMODEL(Operator):
    bl_idname = "api.uploadthreedmodel"
    bl_label = "Upload 3D model"
    bl_description = "This will upload your .gltf and .bin files. If you only did model changes, don't reupload textures to decrease upload/download times"

    def execute(self, context):
        if Unregistered(True): return {'FINISHED'}

        API_UploadModelFiles()
        return {'FINISHED'}
class UPLOAD_3DTEXTURES(Operator):
    bl_idname = "api.uploadtextures"
    bl_label = "Upload textures"
    bl_description = "This will upload all textures in the /textures folder one by one, so it could take a while"

    def execute(self, context):
        if Unregistered(True): return {'FINISHED'}

        API_UploadTextures()
        return {'FINISHED'}
class API_AUTHENTICATE(Operator):
    bl_idname = "api.authenticate"
    bl_label = "Log in"
    bl_description = "Opens a web browser with a login screen."

    def execute(self, context):
        Load_usersettings_from_file()
        if not Authenticated():
            AUTH0API_GetDeviceCode()
        return {'FINISHED'}

class API_LOGOUT(Operator):
    bl_idname = "api.logout"
    bl_label = "log out"
    bl_description = "Log out on this computer."

    def execute(self, context):
        UpdateAuthorizationToken("")
        return {'FINISHED'}

class API_RECONNECT(Operator):
    bl_idname = "api.needsdatarefresh"
    bl_label = "reconnect"
    bl_description = "Get the latest data for this user"

    def execute(self, context):
        global NeedsAuthRefresh
        NeedsAuthRefresh = False
        API_GetSpacesForUser()
        Save_usersettings_file(bpy.context.scene.AuthenticationToken)
        Load_usersettings_from_file()
        return {'FINISHED'}

class API_REGISTER_ASSET(Operator):
    bl_idname = "api.registerasset"
    bl_label = "register asset"
    bl_description = "This will create a new asset for you via the DEXR API. Once you see the ID show up here, it should be registered. Be warned though, if you change the name later on it will register a new asset with the new name and leave the old one existing, so choose your name carefully for now. ---- The user facing name is not set here."

    def execute(self, context):
        # API_UploadThumbnail(f"{GetThumbnailFileName()}.png",f"{GetAssetDir()}{GetThumbnailFileName()}.png",f"{GetThumbnailFileName()}.png")
        API_RegisterAsset(True)
        # bpy.context.view_layer.active_layer_collection.collection["assetID"] = GetAssetId()
        return {'FINISHED'}

class API_COMPLETE_EXPORT(Operator):
    bl_idname = "addon.completeflow"
    bl_label = "Upload to DEXR"
    bl_description = "This will create a new asset for you via the DEXR API from the active Collection. Behind the scenes we will process, export & upload your asset. Please be patient untill the process is finished."

    def execute(self, context):
        # API_UploadThumbnail(f"{GetThumbnailFileName()}.png",f"{GetAssetDir()}{GetThumbnailFileName()}.png",f"{GetThumbnailFileName()}.png")
        # API_RegisterAsset()

        if GetAssetName() == "Scene Collection":
            ShowMessageBox( f"Cannot use the Scene Collection. Please use another collection","Flow Failure")
            return {'FINISHED'}

        FULLSYNC()
        # SetAssetId()
        # bpy.context.view_layer.active_layer_collection.collection["assetID"] = GetAssetId()
        return {'FINISHED'}

class API_GET_ASSETDATA(Operator):
    bl_idname = "api.getassetdata"
    bl_label = "get asset data"
    bl_description = "get asset metadata"

    def execute(self, context):
        API_GetAssetData()
        return {'FINISHED'}
class API_UPDATE_ASSETDATA(Operator):
    bl_idname = "api.updateassetdata"
    bl_label = "update asset data"
    bl_description = "get asset metadata"

    def execute(self, context):
        API_UpdateAssetData()
        return {'FINISHED'}
class PREVIEW_ASSETSTATE(Operator):
    bl_idname = "preview.state"
    bl_label = "preview state"
    bl_description = "todo"

    def execute(self, context):
        ToggleState()
        return {'FINISHED'}

class PICKMESHCHANGEOBJECT(Operator):
    bl_idname = "picker.meshchangeobject"
    bl_label = "pick"
    bl_description = "todo"

    def execute(self, context):
        PickMeshChangeObject()
        return {'FINISHED'}

class BATCHEXPORTALLCOLLECTIONS(Operator):
    bl_idname = "generator.batchallcollections"
    bl_label = "Batch re-export all collections"
    bl_description = "todo"

    def execute(self, context):
        BATCH_ExportAndUploadNextAsset()
        return {'FINISHED'}
class BATCHGETALLASSETMETADATA(Operator):
    bl_idname = "generator.batchgetallassetmetadata"
    bl_label = "BATCH get Asset Metadata for asset"
    bl_description = "todo"

    def execute(self, context):
        # API_GetAssetData()
        BATCH_GetAllAssetMetaDataFromAssetId()
        return {'FINISHED'}

class OPERATORFETCHSPACES(Operator):
    bl_idname = "api.getspaces"
    bl_label = "Get Spaces"
    bl_description = "todo"

    def execute(self, context):
        API_GetSpacesForUser()
        Save_usersettings_file(bpy.context.scene.AuthenticationToken)
        Load_usersettings_from_file()
        return {'FINISHED'}
class SWITCHTODEVELOPMENT_OPERATOR(Operator):
    bl_idname = "auth.switchtodevelopment"
    bl_label = "Development"
    bl_description = ""

    def execute(self, context):
        bpy.context.scene.AdminSettings.production = False
        Initialize()
        return {'FINISHED'}

class SWITCHTOPRODUCTION_OPERATOR(Operator):
    bl_idname = "auth.switchtoproduction"
    bl_label = "Production"
    bl_description = ""

    def execute(self, context):
        bpy.context.scene.AdminSettings.production = True
        Initialize()
        return {'FINISHED'}

class MAKETEXTURESUNIQUE_operator(Operator):
    bl_idname = "help.maketexturesunique"
    bl_label = "Make Textures Unique"
    bl_description = ""

    def execute(self, context):
        MakeTexturesUnique()
        return {'FINISHED'}


class API_MOVEASSET_OPERATOR(Operator):
    bl_idname = "api.moveasset"
    bl_label = "Move Asset to AssetGroup"
    bl_description = "todo"

    def execute(self, context):
        API_MoveAssetToAssetGroup(GetAssetId(),bpy.context.scene.UserSettings.spaces[bpy.context.scene.SelectedSpace].assetCollections[bpy.context.scene.SelectedAssetGroup].id,True)
        return {'FINISHED'}

class API_GETENVIRONMENTS_OPERATOR(Operator):
    bl_idname = "api.getenvironments"
    bl_label = "Get all environments"
    bl_description = "todo"

    def execute(self, context):

        print("getting environments")
        API_GetEnvironments()
        return {'FINISHED'}
class API_CREATEENVIRONMENTS_OPERATOR(Operator):
    bl_idname = "api.createenvironment"
    bl_label = "Create a new environment"
    bl_description = "todo"

    def execute(self, context):
        print("creating environment")
        API_CreateNewEnvironment()
        return {'FINISHED'}

class GENERATOR_THUMBNAIL(Operator):
     bl_idname = "generator.generatethumbnail"
     bl_label = "generate thumbnail"
     bl_description = "This will spawn a new camera and lights, make a thumbnail and then clean up its mess. TODO: add a proper HDRI environment"

     def execute(self, context):
        # if Unregistered(): return {'FINISHED'}
        # API_UploadThumbnail(f"{GetThumbnailFileName()}.png",f"{GetAssetDir()}{GetThumbnailFileName()}.png",f"{GetThumbnailFileName()}.png")

        if GetAssetName() == "Scene Collection":
            ShowMessageBox( f"Cannot use the Scene Collection. Please use another collection","Flow Failure")
            return {'FINISHED'}

        #scene setup
        if context.scene.AddonSettings.UseCurrentCollection:
            isolate_active_collection(True)
        if context.scene.AddonSettings.resetPivot:
            set_all_object_positions_to_Zero()

        generate_thumbnail(GetAssetDir())

        #scene cleanup
        if context.scene.AddonSettings.UseCurrentCollection:
            isolate_active_collection(False)
        if context.scene.AddonSettings.resetPivot:
            set_all_objects_positions_to_cached()

        return {'FINISHED'}

class ASSET_PIPELINE_OT_JSONGENERATOR(Operator):
    bl_idname = "generator.model"
    bl_label = "Generate 3D model"
    bl_description = "This will generate a .gltf file, .bin file and reexport all texture files. Note that the name of the texture in blender will be used, not the source file name. If you imported this model externally this name will also be imported, but you can change it in the texture panel. Texture files are shared in the platform, so make unique names for unique unshareable textures."

    name = bpy.props.StringProperty(name="enter name")

    def execute(self, context):
        if GetAssetName() == "Scene Collection":
            ShowMessageBox( f"Cannot use the Scene Collection. Please use another collection","Flow Failure")
            return {'FINISHED'}
        export_Active_Collection(context)

        return {'FINISHED'}


# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = (
    AssetDefinition,
    AddonSettings,
    # UserRole,
    AdminSettings,
    Login_Panel,
    Simplified_Panel,
    Main_Panel,
    Second_Panel,
    Third_Panel,
    Fourth_Panel,
    Admin_Panel,
    ASSET_PIPELINE_OT_JSONGENERATOR,
    HELP_OPEN_GLTFVIEWER,
    HELP_TOGGLE_GUIDE,
    HELP_DOCUMENTATION,
    UPLOAD_THUMBNAIL_ASSET,
    UPLOAD_3DMODEL,
    UPLOAD_3DTEXTURES,
    GENERATE_ID,
    API_AUTHENTICATE,
    API_LOGOUT,
    API_REGISTER_ASSET,
    API_MOVEASSET_OPERATOR,
    API_GETENVIRONMENTS_OPERATOR,
    API_CREATEENVIRONMENTS_OPERATOR,
    GENERATOR_THUMBNAIL,
    HELP_EXPLORER,
    API_GET_ASSETDATA,
    API_UPDATE_ASSETDATA,
    DexrEnvironment,
    DexrTransform,
    DexrAssetGroup,
    DexrSpace,
    Interactable,
    AssetClass,
    METADATAPANEL,
    MeshChange,
    MeshState,
    PREVIEW_ASSETSTATE,
    PICKMESHCHANGEOBJECT,
    BATCHEXPORTALLCOLLECTIONS,
    BATCHGETALLASSETMETADATA,
    TEST_TOKEN,
    API_COMPLETE_EXPORT,
    SETTINGS_TOGGLESIMPLE,
    UserSettings,
    OPERATORFETCHSPACES,
    SWITCHTOPRODUCTION_OPERATOR,
    SWITCHTODEVELOPMENT_OPERATOR,
    API_RECONNECT,
    MAKETEXTURESUNIQUE_operator

)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    bpy.types.Scene.AssetDefinition = PointerProperty(type=AssetDefinition)
    bpy.types.Scene.AddonSettings = PointerProperty(type=AddonSettings)
    bpy.types.Scene.AdminSettings = PointerProperty(type=AdminSettings)
    # bpy.types.Scene.UserRole = PointerProperty(type=UserRole)
    bpy.types.Scene.UserSettings = PointerProperty(type=UserSettings)
    bpy.types.Scene.SelectedSpace = bpy.props.IntProperty(default=0,min=0)
    bpy.types.Scene.SelectedAssetGroup = bpy.props.IntProperty(default=0,min=0)
    bpy.types.Scene.AuthenticationToken = bpy.props.StringProperty()
    bpy.types.Scene.AuthenticationExpiryUnix = bpy.props.IntProperty()
    bpy.types.Scene.LastKnownDeviceUserCode = bpy.props.StringProperty()
    bpy.types.Scene.RemainingAuthenticationTime = bpy.props.IntProperty()
    bpy.types.Scene.NewEnvironmentName = bpy.props.StringProperty()
    bpy.types.Scene.DexrEnvironments = bpy.props.CollectionProperty(type=DexrEnvironment)
    bpy.types.Scene.SelectedDexrEnvironment = bpy.props.IntProperty(default=0,min=0)
    bpy.types.Collection.assetID = bpy.props.StringProperty(name="Property ID")
    bpy.types.Collection.assetIDDevelopment = bpy.props.StringProperty(name="Property ID")
    bpy.types.Collection.assetGroup = bpy.props.StringProperty(name="Property ID")
    bpy.types.Collection.assetGroupName = bpy.props.StringProperty(name="Property ID")
    bpy.types.Collection.assetSpace = bpy.props.StringProperty(name="Property ID")
    bpy.types.Collection.assetSpaceName = bpy.props.StringProperty(name="Property ID")
    bpy.types.Collection.ClientSpace = bpy.props.StringProperty(name="Property ID")
    bpy.types.Collection.assetMetaData = bpy.props.StringProperty(name="Property ID")
    bpy.types.Collection.AssetMeshChanges = bpy.props.CollectionProperty(type=MeshChange)
    bpy.types.Collection.AssetMeshChanges_active_index = bpy.props.IntProperty(default=0,min=0,update=UpdateAssetStatesDataTest)
    bpy.types.Collection.InteractableMeshChanges = bpy.props.CollectionProperty(type=MeshChange)
    bpy.types.Collection.InteractableMeshChanges_active_index = bpy.props.IntProperty(default=0,min=0)
    bpy.types.Collection.Interactables = bpy.props.CollectionProperty(type=Interactable)
    bpy.types.Collection.Interactables_active_index = bpy.props.IntProperty(default=0,min=0)
    bpy.types.Collection.AssetStates = bpy.props.CollectionProperty(type=MeshState)
    bpy.types.Collection.AssetStates_active_index = bpy.props.IntProperty(default=0,min=0, update=update_AssetStates_active_index)
    bpy.types.Collection.InteractableStates = bpy.props.CollectionProperty(type=MeshState)
    bpy.types.Collection.InteractableStates_active_index = bpy.props.IntProperty(default=0,min=0)
    bpy.types.Collection.Asset = bpy.props.PointerProperty(type=AssetClass)

    bpy.app.handlers.load_post.clear()
    bpy.app.handlers.load_post.append(load_post_handler)



def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

    del bpy.types.Scene.AssetDefinition
    del bpy.types.Scene.AddonSettings
    del bpy.types.Scene.AdminSettings
    # del bpy.types.Scene.UserRole
    del bpy.types.Scene.UserSettings
    del bpy.types.Scene.SelectedSpace
    del bpy.types.Scene.SelectedAssetGroup
    del bpy.types.Scene.AuthenticationToken
    del bpy.types.Scene.AuthenticationExpiryUnix
    del bpy.types.Scene.LastKnownDeviceUserCode
    del bpy.types.Scene.RemainingAuthenticationTime
    del bpy.types.Scene.NewEnvironmentName
    del bpy.types.Scene.DexrEnvironments
    del bpy.types.Scene.SelectedDexrEnvironment
    del bpy.types.Collection.assetID
    del bpy.types.Collection.assetIDDevelopment
    del bpy.types.Collection.assetGroup
    del bpy.types.Collection.assetGroupName
    del bpy.types.Collection.assetSpace
    del bpy.types.Collection.assetSpaceName
    del bpy.types.Collection.ClientSpace
    del bpy.types.Collection.assetMetaData
    del bpy.types.Collection.Asset
    del bpy.types.Collection.Interactables
    del bpy.types.Collection.AssetStates
    del bpy.types.Collection.InteractableStates
    del bpy.types.Collection.AssetMeshChanges
    del bpy.types.Collection.InteractableMeshChanges
    del bpy.types.Collection.Interactables_active_index
    del bpy.types.Collection.AssetStates_active_index
    del bpy.types.Collection.InteractableStates_active_index
    del bpy.types.Collection.AssetMeshChanges_active_index
    del bpy.types.Collection.InteractableMeshChanges_active_index

    bpy.app.handlers.load_post.remove(load_post_handler)


if __name__ == "__main__":
    register()
